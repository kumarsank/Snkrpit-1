import React, { Component } from 'react';
import {
  Container, Content, Text, H1, H2, H3, CardItem, Card, Left, Thumbnail, Body, Button, Icon, Right
} from 'native-base';
import { Image, View, ScrollView, Dimensions } from 'react-native';
import Textt from '../components/Articles/logo';
import Shoes from '../components/Articles/shoes';
import SliderImage from './Articles/SliderImage';
import ImageText from '../components/Articles/imageText';
import { TextInput } from 'react-native-gesture-handler';
export default class About extends Component {
  render() {
    return (
      <Container>
        <Content >


          {/* Top Image and Text START */}
          <CardItem cardBody>
            <Image source={require('../images/Home_Banner.png')} style={{ height: 300, width: null, flex: 1 }} />
            <View style={{ flex: 1, position: 'absolute', right: 0, paddingRight: 40, width: Dimensions.get('window').width, }}>
              <Text style={{ fontWeight: 'bold', fontSize: 10, color: '#32CD32', alignItems: 'stretch', textAlign: 'right' }}>TRADE INTO WINTER</Text>
              <Text style={{ fontWeight: 'bold', fontSize: 30, color: '#fff', textAlign: 'right' }} >Nike Air Max</Text>
              <Text style={{ fontWeight: 'bold', fontSize: 30, color: '#fff', textAlign: 'right' }} >720 Metallic</Text>
              <Text style={{ fontWeight: 'bold', fontSize: 30, color: '#fff', textAlign: 'right' }} >Silver</Text>
            </View>
          </CardItem>

          {/* Top Image and Text END */}



          {/* Trending Trades nand ScrollBar Shoes Images START */}
          
            <Textt Trending="Trending Trades" Viewall="VIEW ALL" />


         
            <View style={{  marginTop: 30, height:230 }}>
           
               
            {/* <ScrollView horizontal={true} style={{flex:1}}
                showsHorizontalScrollIndicator={true}> */}

                {/* {/* <Shoes imageUri={require('../images/product-4.png')} name="NIKE MAX AUR 720" new="NEW" /> */}
                
                <Shoes imageUri={require('../images/product-3.png')} name="NIKE MAX AUR 720" new="NEW" smallText="VERIFIED TRADER" />
               
                {/* </ScrollView> */}
            </View>
   

         
          {/* Trending Trades nand ScrollBar Shoes Images END */}




          <View style={{ flexDirection: 'row', paddingTop: 30 }}>
            <Textt Trending="Trending Trades" Viewall="VIEW ALL" />
          </View>


          {/* ScrollBar PosterImage START */}
          <View style={{ flex: 1, flexDirection: 'row' }}>
            <ScrollView horizontal={true}
              showsHorizontalScrollIndicator={true}>
              <SliderImage bgImage={require('../images/banner-home-2.png')} />
              <SliderImage bgImage={require('../images/banner-home-2.png')} />
              <SliderImage bgImage={require('../images/banner-home-2.png')} />

            </ScrollView>
          </View>
          {/* ScrollBar PosterImage END */}



          {/* Cart and Images DEC START */}
          <View style={{ flex: 1, height: 200, marginTop: 50 }}>

            <View style={{ flex: 0.3, backgroundColor: '#000', flexDirection: 'row' }}>
              <Text style={{ flex: 1, paddingHorizontal: 30, padding: 20, paddingLeft: 40, fontSize: 15, fontWeight: '700', color: '#fff' }}>Top 10 Trending</Text>
              <Text style={{ flex: 1, paddingHorizontal: 30, paddingTop: 25, fontSize: 10, fontWeight: '700', alignItems: 'flex-end', color: '#fff' }}>VIEW All</Text>
            </View>
            <View style={{ flex: 0.7, backgroundColor: '#000' }}>
              {/* Top 10 Trending  START*/}
              <View style={{ flex: 1, backgroundColor: '#fff', marginRight: 30, marginLeft: 30, marginTop: 20, }}>
                <ImageText ImageTextA={require('../images/Home_Banner.png')} dess="CLOT X AIR FORCE 1 PRM ROYAL SLICK" />

                <ImageText ImageTextA={require('../images/Home_Banner.png')} dess="CLOT X AIR FORCE 1 PRM ROYAL SLICK" />

              </View>
            </View>
          </View>
          {/* Cart and Images DEC END */}


          <View style={{ flex: 1, height: 200, backgroundColor: 'grey', marginRight: 30, marginLeft: 30 }}>

            <ImageText ImageTextA={require('../images/Home_Banner.png')} dess="CLOT X AIR FORCE 1 PRM ROYAL SLICK" />

            <ImageText ImageTextA={require('../images/Home_Banner.png')} dess="CLOT X AIR FORCE 1 PRM ROYAL SLICK" />

            <ImageText ImageTextA={require('../images/Home_Banner.png')} dess="CLOT X AIR FORCE 1 PRM ROYAL SLICK" />


          </View>


          <View style={{ flex: 1, height: 250, marginTop: 50 }}>

            <View style={{ flex: 1 }}>
              <View style={{ flex: 0.3, justifyContent: 'center' }}>
                <Text style={{ padding: 20, paddingLeft: 40, fontSize: 15, fontWeight: '700' }}>
                  SPONSOR
                    </Text>
              </View>
              <View style={{ flex: 0.7 }}>
                <Image source={require('../images/Home_Banner.png')} style={{ height: null, width: null, flex: 1 }} />
              </View>
            </View>
          </View>

          <View style={{ flex: 1 }}>
            <View style={{ flex: 0.3 }}>
              <Textt Trending="Top Brands" Viewall="VIEW ALL" />
            </View>
            <ScrollView horizontal={true} style={{ flex: 0.7, height: 150 }}>
              <View style={{ flexDirection: 'row', flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                <View style={{
                  width: 80,
                  height: 80,
                  borderWidth: 1, borderColor: '#F0F0F0', marginLeft: 40, justifyContent: 'center', alignItems: 'center'
                }}>

                  <Image source={require('../images/addidas_1.png')} />

                </View>
                <View style={{
                  width: 80,
                  height: 80,
                  borderWidth: 1, borderColor: '#F0F0F0', marginLeft: 10, justifyContent: 'center', alignItems: 'center'
                }}>
                  <Image source={require('../images/addidas_1.png')} />
                </View>
                <View style={{
                  width: 80,
                  height: 80,
                  borderWidth: 1, borderColor: '#F0F0F0', marginLeft: 10, justifyContent: 'center', alignItems: 'center'
                }}>
                  <Image source={require('../images/addidas_1.png')} />

                </View>
                <View style={{
                  width: 80,
                  height: 80,
                  borderWidth: 1, borderColor: '#F0F0F0', marginLeft: 10, justifyContent: 'center', alignItems: 'center'
                }}>
                  <Image source={require('../images/addidas_1.png')} />

                </View>
              </View>

            </ScrollView>


          </View>
          <View style={{ flex: 1, backgroundColor: '#282828', height: 200 }}>
            <View style={{ flex: 0.1, justifyContent: 'center', alignItems: 'center', marginTop: 25 }}>
              <Text style={{ fontSize: 12, color: '#fff', fontWeight: 'bold' }}>GET THE LATEST UPDATES</Text>
            </View>

            <View style={{ flex: 1, flexDirection: 'row' }}>
              <View style={{ flex: 0.7, paddingLeft: 30, justifyContent: 'center' }}>
                <Text style={{ fontSize: 8, fontWeight: '300', paddingLeft: 5, color: '#fff' }}>Email Address</Text>
                <TextInput style={{ borderBottomWidth: 1, borderBottomColor: '#fff', color: '#fff', }} placeholderTextColor="#696969" placeholder="Enter your email address" />
              </View>
              <View style={{ flex: 0.3, alignItems: 'center', justifyContent: 'center' }}>
                <View style={{
                  width: 50,
                  height: 60, justifyContent: 'center', alignItems: 'center', backgroundColor: 'green'
                }}>
                  <Image source={require('../images/send_1.png')} />
                </View>
              </View>
            </View>



          </View>


        </Content>
      </Container>
    );
  }

}

