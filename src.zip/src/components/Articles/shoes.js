import React, { Component } from 'react';
import { View, SafeAreaView, Text, TouchableOpacity, Image } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { Container, Content } from 'native-base';

export default class Shoes extends Component {
    render() {
        return (


// <ScrollView>
// <Container style={{ flex: 1, flexDirection: 'row' }}>
<View style={{ flex: 1, flexDirection: 'row' }}>
           
                <View style={{ flex:0.5 , backgroundColor:'green'}} >
                    {/* <View style={{ borderWidth: 1, borderColor: '#F5F5F5' }}> */}
                    <Text style={{ fontSize: 12, fontWeight: 'bold', paddingLeft: 7, paddingTop: 5 }}>{this.props.new}</Text>
                    <View style={{  justifyContent: 'center', alignItems: 'center' }}>
                        <TouchableOpacity activeOpacity={0.8} style={{}} onPress={() => alert('hello')}>
                            <Image style={{ height: 70, width: 140 }} source={this.props.imageUri} />
                        </TouchableOpacity>
                    </View>
                    <View style={{ flex: 0.4, paddingLeft: 10 }}>
                        <View style={{ flex: 0.2, alignItems: 'flex-start', justifyContent: 'flex-start' }}>
                            <TouchableOpacity
                                onPress={() => alert('helloooo')} style={{ flexDirection: 'row', borderWidth: 1, borderColor: '#eeeeee', padding: 4 }}>
                                <Image source={require('../../images/dope-icon.png')} style={{ marginRight: 3 }} />
                                <Text style={{ fontSize: 6, letterSpacing: 0.6, textTransform: 'uppercase', color: '#404040' }}>{this.props.smallText}</Text></TouchableOpacity>
                        </View>
                        <Text style={{ fontSize: 13, paddingTop: 20 }}>{this.props.name}</Text>
                    </View>
                    {/* </View>  */}
                </View>



         



     

                </View>
          
          
            // </Container>


            // </ScrollView>


         

        );
    }
}